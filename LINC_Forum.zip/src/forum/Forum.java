package forum;

public class Forum {
	
		public int n_PostOrder;
		public String s_WriteDay;
		public String s_Title;
		public String s_Content;
		public String s_PostUser;
		public int n_ViewCount;
		public int n_GoodCount; 
		public int n_BadCount;
		public int is_Delete;
		public int n_ForumCategory;
		
		
		
		public int getN_PostOrder() {
			return n_PostOrder;
		}
		public void setN_PostOrder(int n_PostOrder) {
			this.n_PostOrder = n_PostOrder;
		}
		public String getS_WriteDay() {
			return s_WriteDay;
		}
		public void setS_WriteDay(String s_WriteDay) {
			this.s_WriteDay = s_WriteDay;
		}
		public String getS_Title() {
			return s_Title;
		}
		public void setS_Title(String s_Title) {
			this.s_Title = s_Title;
		}
		public String getS_Content() {
			return s_Content;
		}
		public void setS_Content(String s_Content) {
			this.s_Content = s_Content;
		}
		public String getS_PostUser() {
			return s_PostUser;
		}
		public void setS_PostUser(String s_PostUser) {
			this.s_PostUser = s_PostUser;
		}
		public int getN_ViewCount() {
			return n_ViewCount;
		}
		public void setN_ViewCount(int n_ViewCount) {
			this.n_ViewCount = n_ViewCount;
		}
		public int getN_GoodCount() {
			return n_GoodCount;
		}
		public void setN_GoodCount(int n_GoodCount) {
			this.n_GoodCount = n_GoodCount;
		}
		public int getN_BadCount() {
			return n_BadCount;
		}
		public void setN_BadCount(int n_BadCount) {
			this.n_BadCount = n_BadCount;
		}
		public int getIs_Delete() {
			return is_Delete;
		}
		public void setIs_Delete(int is_Delete) {
			this.is_Delete = is_Delete;
		}
		public int getN_ForumCategory() {
			return n_ForumCategory;
		}
		public void setN_ForumCategory(int n_ForumCategory) {
			this.n_ForumCategory = n_ForumCategory;
		}
		
		
		
		
		
	}
