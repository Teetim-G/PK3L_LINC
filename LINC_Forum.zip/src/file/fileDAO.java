package file;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class fileDAO {
	private Connection conn;
	public fileDAO() {
	try {

		String dbURL = "jdbc:mysql://61.84.24.210:3306/linc_?serverTimezone=UTC";
		String dbID = "LINC_C";
		String dbPassword = "daelim1!";
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

	} catch(Exception e) {

		e.printStackTrace();

	}
	}




public int upload(String n_PostNum, String s_Directory) {

	String SQL = "INSERT INTO image VALUES (?, ?)";

	try {

		PreparedStatement pstmt = conn.prepareStatement(SQL);

		pstmt.setString(1,  n_PostNum);

		pstmt.setString(2,  s_Directory);

		return pstmt.executeUpdate();

	} catch(Exception e) {

		e.printStackTrace();

	}

	return -1;

}

}