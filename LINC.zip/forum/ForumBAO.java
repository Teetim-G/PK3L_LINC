package forum;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ForumBAO {
	private Connection conn;
	private ResultSet rs;
	
	public ForumBAO() {
		try {
			
			String url = "jdbc:mysql://61.84.24.210:3306/linc_c?serverTimezone=UTC";
			String user = "LINC_C";
			String password = "daelim1!";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url,user,password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getDate() {
		String SQL = "SELECT NOW()";
				try{
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						return rs.getString(1);
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
				return "";
	}
	public int getNext() {
		String SQL = "SELECT n_PostOrder FROM forum ORDER BY n_PostOrder DESC";
				try{
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						return rs.getInt(1) + 1;
					}
					return 1;
				} catch(Exception e) {
					e.printStackTrace();
				}
				return -1;
	}
	public int write(String s_Title, String s_PostUser, String s_Content) {
		String SQL = "INSERT INTO forum (n_PostOrder, s_WriteDay, s_Title, s_Content, s_PostUser, n_ViewCount, n_GoodCount,  n_BadCount, is_Delete, n_ForumCategory) VALUES(? ,? ,? ,?, ?, ?, ?, ?, ?, ?)";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, getDate());
			pstmt.setString(3, s_Title);
			pstmt.setString(4, s_Content);
			pstmt.setString(5, s_PostUser);	
			pstmt.setInt(6, 0);	
			pstmt.setInt(7, 0);
			pstmt.setInt(8, 0);
			pstmt.setInt(9, 1);	
			pstmt.setInt(10, 0);	
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public ArrayList<Forum> getList(int pageNumber){
		String SQL = "SELECT * FROM forum WHERE n_PostOrder < ? AND is_Delete = 1 ORDER BY n_PostOrder DESC LIMIT 10";
		ArrayList<Forum> list = new ArrayList<Forum>();
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Forum forum = new Forum();
				forum.setN_PostOrder(rs.getInt(1));
				forum.setS_WriteDay(rs.getString(2));
				forum.setS_Title(rs.getNString(3));
				forum.setS_Content(rs.getNString(4));
				forum.setS_PostUser(rs.getNString(5));
				forum.setN_ViewCount(rs.getInt(6));
				forum.setN_GoodCount(rs.getInt(7));
				forum.setN_BadCount(rs.getInt(8));
				forum.setIs_Delete(rs.getInt(9));
				forum.setN_ForumCategory(rs.getInt(10));
				list.add(forum);
			}
		
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;
}
	
	public boolean nextPage(int pageNumber) {
		String SQL = "SELECT * FROM forum WHERE n_PostOrder < ? AND is_Delete = 1";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				return true;
			}
		
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
}
	public Forum getForum(int n_PostOrder) {

		String SQL = "SELECT * FROM forum WHERE n_PostOrder = ?";

		try {

			PreparedStatement pstmt = conn.prepareStatement(SQL);

			pstmt.setInt(1, n_PostOrder);

			rs = pstmt.executeQuery();

			if (rs.next()) {

				Forum forum = new Forum();
				forum.setN_PostOrder(rs.getInt(1));
				forum.setS_WriteDay(rs.getString(2));
				forum.setS_Title(rs.getNString(3));
				forum.setS_Content(rs.getNString(4));
				forum.setS_PostUser(rs.getNString(5));
				forum.setN_ViewCount(rs.getInt(6));
				forum.setN_GoodCount(rs.getInt(7));
				forum.setN_BadCount(rs.getInt(8));
				forum.setIs_Delete(rs.getInt(9));
				forum.setN_ForumCategory(rs.getInt(10));

				return forum;

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

		return null;



	}
	public int update(int n_PostOrder, String s_Title, String s_Content) {

		String SQL = "UPDATE forum SET s_Title = ?, s_Content = ?, WHERE n_PostOrder = ?";

		try {

			PreparedStatement pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, s_Title);

			pstmt.setString(2, s_Content);

			pstmt.setInt(3, n_PostOrder);

			return pstmt.executeUpdate();



		} catch (Exception e) {

			e.printStackTrace();

		}

		return -1; // �����ͺ��̽� ����

	}
	public int delete(int n_PostOrder) {

		String SQL = "UPDATE forum SET is_Delete = 0 WHERE n_PostOrder = ?";

		try {

			PreparedStatement pstmt = conn.prepareStatement(SQL);   

			pstmt.setInt(1, n_PostOrder);

			return pstmt.executeUpdate();



		} catch (Exception e) {

			e.printStackTrace();

		}

		return -1; // �����ͺ��̽� ����



	}

}




	
	
	
	




